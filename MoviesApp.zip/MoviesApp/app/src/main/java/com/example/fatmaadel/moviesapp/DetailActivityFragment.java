package com.example.fatmaadel.moviesapp;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * A placeholder fragment containing a simple view.
 */
public class DetailActivityFragment extends Fragment {
    DB_Helper db_helper;
    MovieModel movie= new MovieModel();
    ArrayList<MovieModel> models;
    SQLiteDatabase sqLiteDatabase;

   // DatabaseFavouriteMovies DB =new DatabaseFavouriteMovies(getActivity().getApplicationContext());

  static SharedPreferences shared ;
    String IDS;
    ArrayList<String> Reviews;
    ArrayList<String>trailerkey;

    public  ArrayAdapter<String> REviewAdapter;
    public ArrayAdapter<String> TrailerAdapter;

    float rate;
    String ID;
    String TITEL;
    String RealseDate;
    String OVerView;
    String POSTER;
    String Rate;
    TextView Movie_Title;
    ImageView Movie_Image;
    TextView overView;
    TextView Release_date;
    TextView RateView;
    TextView Review;
    TextView  Trailer;
    ListView Review_list;
    ListView trailer_list;

    Context context;
    GridView favorite_Movie_GridView;

    Button button;

    public DetailActivityFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        //return inflater.inflate(R.layout.fragment_detail, container, false);
        View view = inflater.inflate(R.layout.fragment_detail, container, false);
        Movie_Title = (TextView) view.findViewById(R.id.titleView);
        Movie_Image = (ImageView) view.findViewById(R.id.movieImage);
        overView = (TextView) view.findViewById(R.id.OverView);
        Release_date = (TextView) view.findViewById(R.id.ReleaseData);
      RateView= (TextView) view.findViewById(R.id.RateView);
        Review= (TextView) view.findViewById(R.id.Review);
        Review_list=(ListView)view.findViewById(R.id.favorite_ListReview);
        trailer_list=(ListView) view.findViewById(R.id.Movie_Trailers);
        button=(Button)view.findViewById(R.id.favourite_btn);
        // Trailer=(TextView) view.findViewById(R.id.Trailer);


       //final Bundle bundle= getActivity().getIntent().getBundleExtra("MovieData")  ;
        Intent intent = getActivity().getIntent();



        if(MainActivity.istablet==true)
        {
            ID=getArguments().getString("id");
            TITEL=getArguments().getString("title");
            RealseDate=getArguments().getString("relasedate");
            OVerView=getArguments().getString("overview");
            POSTER=getArguments().getString("posterpath");
            Rate=getArguments().getString("rate");




        }
        else {
            Bundle bundle = this.getActivity().getIntent().getExtras();


            ID = bundle.getString("id");
            Log.d("Idahmed", ID);
            TITEL = bundle.getString("title");
            RealseDate = bundle.getString("relasedate");
           OVerView = bundle.getString("overview");
            POSTER = bundle.getString("posterpath");
           Rate = bundle.getString("rate");
        }
//            movie.setOriginal_title(bundle.getString("title"));
//            movie.setRelease_date(bundle.getString("relasedate"));
//            movie.setOverview(bundle.getString("overview"));
//            movie.setMovie_id(bundle.getString("id"));
//            movie.setPoster(bundle.getString("posterpath"));
//            movie.setVote_average(bundle.getString("rate");
//
//

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context context = getActivity();
                shared = context.getSharedPreferences("FavouriteMovie", Context.MODE_PRIVATE);
                int C = 0;
                SharedPreferences.Editor editor = shared.edit();
                IDS = shared.getString("FavMovie_id", "");
                String[] Result = IDS.split("_");
                for (int i = 0; i < Result.length; i++) {
                    if (ID.equals(Result[i])) {
                        C = 1;


                    }
                }
                if (C == 0) {
                    String ids = ID + "_";
                    ids = IDS + ids;
                    editor.putString("FavMovie_id", ids);
                    editor.commit();
                }
                button.setBackgroundColor(Color.YELLOW);
              //  Toast.makeText(getActivity(),""+shared.getString("FavMovie_id", ""),Toast.LENGTH_SHORT).show();
                Toast.makeText(getActivity(),"Movie_Saved",Toast.LENGTH_SHORT).show();
            }
            // Favorts_Ids = sharedPreferences.getString("Movie_id", "");

//                db_helper=new DB_Helper(getActivity());
//                sqLiteDatabase =db_helper.getWritableDatabase();
//                button.setBackgroundColor(Color.YELLOW);
//                db_helper.insertfavouriteMovie(movie.getOriginal_title(),movie.getPoster(), movie.getOverview(),
//                        movie.getRelease_date(),
//                        movie.getMovie_id(),sqLiteDatabase);
//                Toast.makeText(getActivity(), "Movie Saved !", Toast.LENGTH_LONG).show();
//                sqLiteDatabase.close();
//                db_helper.close();
//


       });



       // Toast.makeText(getActivity(),ID, Toast.LENGTH_SHORT).show();

        Movie_Title.setText(TITEL);
        overView.setText(OVerView);
        Release_date.setText(RealseDate);

    RateView.setText(Rate);
        Picasso.with(context)
                .load("http://image.tmdb.org/t/p/w300" + POSTER)
                .into(Movie_Image);


        ReviewS reviewS=new ReviewS();
        reviewS.execute(ID);
        Traile  traile=new Traile();
        traile.execute(ID);


//        Bundle bundle = getArguments();
//        if (bundle != null) {
//            movieModel.setPoster(bundle.getString("poster_path"));
//            movieModel.setId(bundle.getString("id"));
//            movieModel.setOriginal_title(bundle.getString("original_title"));
//            movieModel.setRelease_date(bundle.getString("release_date"));
//            movieModel.setOverview(bundle.getString("overview"));
//
//
//           // Bundle b = this.getIntent().getExtras();
//            //String Poster = b.getString("poster_path");
//




//        }
//        return view;


      return view;


    }


    @Override
    public void onStart() {
        super.onStart();

    }

    public class ReviewS extends AsyncTask<String,Void,ArrayList<MovieModel> > {


        @Override
        protected ArrayList<MovieModel> doInBackground(String... Url) {
            HttpURLConnection urlConnection = null;



            try {
                  Reviews=new ArrayList<>();
                final String API_KEY_PARAM = "api_key";
                Uri.Builder builder = new Uri.Builder();
                builder.scheme("https")
                        .authority("api.themoviedb.org")
                        .appendPath("3")
                        .appendPath("movie")
                        .appendPath(ID)
                        .appendPath("reviews")
                        .appendQueryParameter(API_KEY_PARAM, "f422e13255a0c5243a1627cb14581228").build();


                URL url = new URL(builder.toString());


                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();

                if (inputStream == null) {
                    // Nothing to do.
                    return null;
                }
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {

                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    return null;
                }
                JSONObject jsonObject = new JSONObject(buffer.toString());
                JSONArray jsonArray = jsonObject.getJSONArray("results");



                //  list =new LinkedList<>();
                for (int i = 0; i < jsonArray.length(); i++) {

                    Reviews.add(jsonArray.getJSONObject(i).get("author").toString());
                    Reviews.add(jsonArray.getJSONObject(i).get("content").toString());

                }
                Log.d("reviewssss","" +Reviews);

            } catch (Exception e) {
                Log.e("error", "Error ", e);
                return null;
            }

            return null;
        }

        @Override
        protected void onPostExecute(ArrayList<MovieModel> result) {
            super.onPostExecute(result);

            REviewAdapter=new ArrayAdapter<String>(getActivity(),R.layout.review,R.id.review_textView,Reviews);
            Review_list.setAdapter(REviewAdapter);



             //   Reviewss.setAdapter(new ReviewAdapter(getContext(),Reviews));
//               ReviewAdapter review_adapter = new ReviewAdapter(getActivity().getApplicationContext(),Reviews);
//
//                Reviewss.setAdapter(review_adapter);





        }

    }
    public class Traile extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String... Url) {
            HttpURLConnection urlConnection = null;
            trailerkey=new ArrayList<>();

            try {
//                 URL movieURL;
//                movieURL = new URL("https://api.themoviedb.org/3/movie/popular?api_key=f422e13255a0c5243a1627cb14581228");
//                HttpURLConnection urlConnection = (HttpURLConnection) movieURL.openConnection();
                if (Url.length == 0) {
                    return null;
                }



                final String API_KEY_PARAM = "api_key";
                //final String PAGE_PARAM = "page";
                Uri.Builder builder = new Uri.Builder();

                builder.scheme("https")
                         .authority("api.themoviedb.org" )
                         .appendPath("3")
                         .appendPath("movie")
                         .appendPath(ID)
                        .appendPath("videos")
                         .appendQueryParameter(API_KEY_PARAM, "f422e13255a0c5243a1627cb14581228").build();


                URL url = new URL(builder.toString());


                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                InputStream inputStream=urlConnection.getInputStream();
                StringBuffer buffer =new StringBuffer();


                if (inputStream == null) {
                    // Nothing to do.
                    return null;
                }
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {

                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    // Stream was empty.  No point in parsing.
                    return null;
                }
                JSONObject jsonObject=new JSONObject( buffer.toString());
                JSONArray jsonArray=jsonObject.getJSONArray("results");

                for(int i=0;i<jsonArray.length();i++){
                    // JSONObject movies=jsonArray.getJSONObject(i);
                    trailerkey.add(jsonArray.getJSONObject(i).getString("key"));

                }
                Log.d("trailer",""+trailerkey);
                return buffer.toString();


            }catch (Exception e) {
                Log.e("error", "Error ", e);
                return null;
            }

        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);


            TrailerAdapter=new ArrayAdapter<String>(getActivity(),R.layout.trailer,R.id.List_Item_Trailer,trailerkey);
            trailer_list.setAdapter(TrailerAdapter);

            trailer_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    String key=TrailerAdapter.getItem(position);
                    String tr =trailerkey.get(position);
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v="+tr)));




                }
            });
//            grid.setAdapter(new GridAdapter(getActivity(),posters));
//            Log.d("IDssssss",""+Id);
//            Log.d("Postersssssssssssssssss",""+posters);
//            Log.d("Titlesssssssss",""+Title);
//            Log.d("Overrssssss", "" + Over);
//            Log.d("Releseeeeeee", "" + ReliseDate);


        }
    }

}

