package com.example.fatmaadel.moviesapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by fatma adel on 5/1/2016.
 */
public class DB_Helper extends SQLiteOpenHelper {

    static final String DB_Name="favourite_Movies";
    static final int DB_Version=3;

    public DB_Helper(Context context) {
        super(context, DB_Name, null, DB_Version);
        Log.e(" database operation", "database created / opened");
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(Movie_Contract.Create_TB);
        Log.e(" database operation", "database created !");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL(Movie_Contract.Drop_TB);
        onCreate(sqLiteDatabase);
    }

    public void insertfavouriteMovie(String title,String poster,  String overview ,String release , String movie_id, SQLiteDatabase db){
        ContentValues contentValues=new ContentValues();

        contentValues.put(Movie_Contract.FavouriteMovie.NAME,title);
        contentValues.put(Movie_Contract.FavouriteMovie.POSTER,poster);
        contentValues.put(Movie_Contract.FavouriteMovie.OVER,overview);
       // contentValues.put(Movie_Contract.FavouriteMovie._AVG,rating);
        contentValues.put(Movie_Contract.FavouriteMovie.RELESE,release);
        contentValues.put(Movie_Contract.FavouriteMovie.MOVIE_ID,movie_id);



        db.insert(Movie_Contract.FavouriteMovie.TABLE_NAME, null, contentValues);

        Log.e(" database operation", "favourite movie inserted !");
        Log.d("ddatabaseeeeeeeeeee",""+db);
    }

    public Cursor getfavouriteMovie(SQLiteDatabase db){
        Cursor cursor;
        String[] projections ={ Movie_Contract.FavouriteMovie.NAME,Movie_Contract.FavouriteMovie.POSTER,
                Movie_Contract.FavouriteMovie.OVER,Movie_Contract.FavouriteMovie.RELESE,Movie_Contract.FavouriteMovie.MOVIE_ID};
        cursor= db.query(Movie_Contract.FavouriteMovie.TABLE_NAME, projections, null, null,null,null, null);

//Movie_Contract.FavouriteMovie._AVG,

        return cursor;
    }
}
