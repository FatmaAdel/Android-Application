package com.example.fatmaadel.moviesapp;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by fatma adel on 4/23/2016.
 */
public class GridAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<String> IMages;

    public GridAdapter(Context mContext, ArrayList<String> URlIMage) {
        IMages = URlIMage;
        context = mContext;
    }



    @Override
    public int getCount() {
        return IMages.size();
    }

    @Override
    public Object getItem(int position) {
        return IMages.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // LayoutInflator to call external grid_item.xml file
        ImageView imageView;
        if (convertView == null) {
            imageView = new ImageView(context);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);


        } else {


            imageView = (ImageView) convertView;
        }

        Picasso.with(context)
                .load("http://image.tmdb.org/t/p/w300" + IMages.get(position))
                .into(imageView);
        return imageView;
    }
}




