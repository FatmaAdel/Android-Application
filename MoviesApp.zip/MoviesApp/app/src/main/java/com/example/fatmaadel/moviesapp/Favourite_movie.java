package com.example.fatmaadel.moviesapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import java.util.ArrayList;

/**
 * Created by fatma adel on 5/1/2016.
 */
public class Favourite_movie extends AppCompatActivity {
    public static GridAdapter gridAdapter;
    public static ArrayList<String> title = new ArrayList<>();
    public static ArrayList<String> Overview = new ArrayList<>();
    public static ArrayList<String> Poster ;
    public static ArrayList<String> release = new ArrayList<>();
    public static ArrayList<Float> average = new ArrayList<>();
    public static ArrayList<Integer> MovieID = new ArrayList<>();


    GridView favorite_Movie_GridView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_main);
        favorite_Movie_GridView = (GridView) findViewById(R.id.favorite_gridView);
        //    Toast.makeText(getApplicationContext(), "on resume", Toast.LENGTH_SHORT).show();

        //    Toast.makeText(getApplicationContext(), "on resume", Toast.LENGTH_SHORT).show();
        Poster = new ArrayList<>();
        DB_Helper MyHelperClass = new DB_Helper(getApplicationContext());
        SQLiteDatabase db = MyHelperClass.getReadableDatabase();
        MyHelperClass.onOpen(db);
        Cursor cursor = MyHelperClass.getfavouriteMovie(db);
        if (cursor.moveToFirst()) {
            do {

                String Image = cursor.getString(cursor.getColumnIndex(Movie_Contract.FavouriteMovie.POSTER));
                Poster.add(Image);

                String Title_Movie = cursor.getString(cursor.getColumnIndex(Movie_Contract.FavouriteMovie.NAME));
                title.add(Title_Movie);

                String Release_Movie = cursor.getString(cursor.getColumnIndex(Movie_Contract.FavouriteMovie.RELESE));
                release.add(Release_Movie);

//                final Float Average = cursor.getFloat(cursor.getColumnIndex(Movie_Contract.FavouriteMovie._AVG));
//                average.add(Average);

                String DESC = cursor.getString(cursor.getColumnIndex(Movie_Contract.FavouriteMovie.OVER));
                Overview.add(DESC);
                final int movieID = cursor.getInt(cursor.getColumnIndex(Movie_Contract.FavouriteMovie.MOVIE_ID));
                MovieID.add(movieID);

                gridAdapter = new GridAdapter(getApplicationContext(), Poster);
                favorite_Movie_GridView.setAdapter(gridAdapter);
                /* movie_movieAdapter = new MovieAdapter(getApplicationContext(), R.layout.movie_image_item ,Poster);
                favorite_Movie_GridView.setAdapter(movie_movieAdapter);
                */
                favorite_Movie_GridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                                                                   @Override
                                                                   public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                                                                       String POSTER_PATH = Poster.get(position);

                                                                       Intent favorite_detailPage= new Intent(getApplicationContext(), DetailActivityFragment.class);
                                                                       favorite_detailPage.putExtra("title", title.get(position));
                                                                       favorite_detailPage.putExtra("overview", Overview.get(position));
                                                                       favorite_detailPage.putExtra("relasedate", release.get(position));
                                                                       favorite_detailPage.putExtra("id", MovieID.get(position));
                                                                       favorite_detailPage.putExtra("posterpath", Poster.get(position));
                                                                      // favorite_detailPage.putExtra("vote_average",average.get(position) );

                                                                       //  float c =ratingBar.setRating(movieList.get(position).getVote_average() / 2);

                                                                       startActivity(favorite_detailPage);


                                                                   }
                                                               }
                );

            }
            while (cursor.moveToNext());
        }  db.close();
        cursor.close();
        MyHelperClass.close();
    }
    /*
        public  void setPane(Boolean mTwoPane){
            this.mTwoPane=mTwoPane;
        }

        public Boolean getPane(){
            return mTwoPane;
        }
    */
    public void onResume() {
        super.onResume();




    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}

