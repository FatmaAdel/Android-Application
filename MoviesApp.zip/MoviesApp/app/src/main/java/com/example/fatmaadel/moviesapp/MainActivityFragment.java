package com.example.fatmaadel.moviesapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

/**
 * A placeholder fragment containing a simple view.
 */
public class MainActivityFragment extends Fragment {

    //DatabaseFavouriteMovies DB = new DatabaseFavouriteMovies(getActivity());
    GridView grid;
    ArrayList<MovieModel> movieModel;
    int con;
    String[] DataID;
    GridAdapter gridAdapter;
    ArrayList<String> posters;
    ArrayList<String> Id;
    ArrayList<String> Title;
    ArrayList<String> Over;
    ArrayList<String> ReliseDate;
    ArrayList<String> Rate;

    //static onHeadLineClickListner onHeadLineClickListner;


    Context context;


    View rootView;

    @Override
    public void onStart() {
        super.onStart();
        new AllMovies().execute("http://api.themoviedb.org/3/discover/movie?primary_release_date.gte=2014-09-15&primary_release_date.lte=2014-10-22&api_key=1a6f3da4163bd0a09e2057ff55586201");

    }

    private static final String DetailFragment = "DFT";
   // private int mPosition = GridView.INVALID_POSITION;
    //private static final String SELECTED_KEY = "selected_position";

    public MainActivityFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);

        inflater.inflate(R.menu.menu_main, menu);
    }


//    public interface onHeadLineClickListner {
//        public void HeadLineListner(MovieModel movieModel);
//    }

//    @Override
//    public void onAttach(Activity activity) {
//        super.onAttach(activity);
//        getActivity();
//        try {
//            onHeadLineClickListner = (MainActivityFragment.onHeadLineClickListner) activity;
//        } catch (Exception e) {
//            Log.e("tablet", " Errorrrrrrrr");
//        }
//    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        //super.onOptionsItemSelected(item);
        int id = item.getItemId();
        if (id == R.id.Popular) {
//            posters.clear();
            movies pop = new movies();
            pop.execute("popular");
            return true;
        }

        if (id == R.id.TopRate) {
//            posters.clear();
            movies pop = new movies();
            pop.execute("top_rated");
        }

        if (id == R.id.favourite) {
            posters = new ArrayList<>();
            Id = new ArrayList<>();
            Over = new ArrayList<>();
            ReliseDate = new ArrayList<>();
            Title = new ArrayList<>();
            Rate = new ArrayList<>();
            DetailActivityFragment.shared = getActivity().getSharedPreferences("FavouriteMovie", Context.MODE_PRIVATE);
            String Favourite_ids = DetailActivityFragment.shared.getString("FavMovie_id", "");
            DataID = Favourite_ids.split("_");
            for (int i = 0; i < DataID.length; i++) {
                FavouriteMovies G = new FavouriteMovies();

                G.execute(DataID[i]);

                con++;
            }
            return true;

        }
        return true;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        rootView = inflater.inflate(R.layout.fragment_main, container, false);
        grid = (GridView) rootView.findViewById(R.id.grid);


        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            Bundle b = new Bundle();


            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // String movie = (String) gridAdapter.getItem(position);
                // movieModel =new ArrayList<>();
               // if (getActivity() != null) {

//                    MovieModel movieModels = new MovieModel();
//
//
//                    movieModels =(MovieModel) gridAdapter.getItem(position);
//
//                    MainActivity mainActivity = (MainActivity) getActivity();
//                    Boolean paneValue = mainActivity.getPane();
//                      if (paneValue) {
//                        onHeadLineClickListner.HeadLineListner(movieModels);
//
//
//                        mPosition = position;
//                     } else {
                DetailActivityFragment detialedFragment=new DetailActivityFragment();

                        Intent intent = new Intent(getActivity(), DetailActivity.class);
                        String movie_id = Id.get(position);
                        String movie_title = Title.get(position);
                        String movie_overview = Over.get(position);
                        String movie_relasedate = ReliseDate.get(position);
                        String movie_poster = posters.get(position);
                        String movie_rate = Rate.get(position);


                      //  DetailActivityFragment movieDetail = new DetailActivityFragment();
                        // Bundle bundle = new Bundle();
                        //FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();

                        b.putString("id", movie_id);
                        b.putString("title", movie_title);
                        b.putString("overview", movie_overview);
                        b.putString("relasedate", movie_relasedate);
                        b.putString("posterpath", movie_poster);
                        b.putString("rate", movie_rate);
                        //intent.putExtra("MovieData", b);
                if(MainActivity.istablet==true)
                {

                    detialedFragment.setArguments(b);
                    getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.frame, detialedFragment).commit();
                    intent.putExtras(b);
//                    intent.putExtra("MovieData", b);
                }
else {
                    //movieDetail.setArguments(b);
//                    intent.putExtra("MovieData", b);
                    intent.putExtras(b);

                    startActivity(intent);
//                        fragmentTransaction.replace(R.id.fragment, movieDetail, DetailFragment);
//                        fragmentTransaction.addToBackStack(null).commit();

                }
                    }
//                }


            //Toast.makeText(getActivity(), Title.get(position), Toast.LENGTH_SHORT).show();
        });



//
//        if (mPosition != GridView.INVALID_POSITION) {
//            // If we don't need to restart the loader, and there's a desired position to restore
//            // to, do so now.
//            grid.smoothScrollToPosition(mPosition);
//        }
//        grid.setAdapter(new GridAdapter(getActivity(),list));
            return rootView;

    }



    @Override
    public void onSaveInstanceState(Bundle outState) {
        // When tablets rotate, the currently selected list item needs to be saved.
        // When no item is selected, mPosition will be set to Listview.INVALID_POSITION,
        // so check for that before storing.
//        if (mPosition != GridView.INVALID_POSITION) {
//            outState.putInt(SELECTED_KEY, mPosition);
//        }
        super.onSaveInstanceState(outState);
    }


    public class AllMovies extends AsyncTask <String,Void,String> {
         @Override
         protected void onPreExecute() {
             super.onPreExecute();
             movieModel =new ArrayList<>();
         }

         @Override
         protected String doInBackground(String... params) {
             HttpURLConnection connection = null;
             BufferedReader reader = null;
             try {
                 URL url = new URL(params[0]);
                 connection = (HttpURLConnection) url.openConnection();
                 connection.connect();

                 InputStream stream = connection.getInputStream();
                 reader = new BufferedReader(new InputStreamReader(stream));

                 StringBuffer buffer = new StringBuffer();
                 String line = "";
                 while ((line = reader.readLine()) != null) {

                     buffer.append(line);
                 }
                 //String finalJson = buffer.toString();


                JSONObject jsonObject = new JSONObject(buffer.toString());
                 JSONArray jsonArray = jsonObject.getJSONArray("results");
                 posters = new ArrayList<>();
                 Id = new ArrayList<>();
                 Over = new ArrayList<>();
                 ReliseDate = new ArrayList<>();
                 Title = new ArrayList<>();
                 Rate = new ArrayList<>();

                 for (int i = 0; i < jsonArray.length(); i++) {
                      //  JSONObject movies=jsonArray.getJSONObject(i);
                     posters.add(jsonArray.getJSONObject(i).get("poster_path").toString());
                     Id.add(jsonArray.getJSONObject(i).get("id").toString());
                     Title.add(jsonArray.getJSONObject(i).get("original_title").toString());
                     Over.add(jsonArray.getJSONObject(i).get("overview").toString());
                     ReliseDate.add(jsonArray.getJSONObject(i).get("release_date").toString());
                     Rate.add(jsonArray.getJSONObject(i).get("vote_average").toString());


                 }
//                 if (jsonArray ==null){
//                     Toast.makeText(getActivity(),"No internet Connection",Toast.LENGTH_SHORT).show();
//                 }


             } catch (MalformedURLException e) {
                 e.printStackTrace();
             } catch (IOException e) {
                 e.printStackTrace();
             } catch (JSONException e) {
                 e.printStackTrace();
             } finally {
                  if (connection != null) {
                     connection.disconnect();
                  }
                 try {
                     if (reader != null) {
                         reader.close();
                     }
                 } catch (IOException e) {
                     e.printStackTrace();
                 }
             }
             return null;
         }

         @Override
         protected void onPostExecute(String Result) {
             super.onPostExecute(Result);
           //  if (getActivity() != null) {
                //final GridAdapter movieAdapter = new GridAdapter(getActivity(), R.layout.grid_item, Result);

                 grid.setAdapter(new GridAdapter(getActivity(), posters));

             }
         }

///////////////////////////////////////////////////////////////////////////////////
    public class movies extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String... Url) {
            HttpURLConnection urlConnection = null;
            String data = "";


            try {
           final String API_KEY_PARAM = "api_key";
                Uri.Builder builder = new Uri.Builder();
                builder.scheme("https")
                        .authority("api.themoviedb.org")
                        .appendPath("3")
                        .appendPath("movie")
                        .appendPath(Url[0])
                        .appendQueryParameter(API_KEY_PARAM, "09ef905fb0a8f078de853a6aa6ac8983").build();


                URL url = new URL(builder.toString());

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();

                if (inputStream == null) {
                    // Nothing to do.
                    return null;
                }
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {

                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    // Stream was empty.  No point in parsing.
                    return null;
                }
                data = buffer.toString();

                JSONObject jsonObject = new JSONObject(buffer.toString());
                JSONArray jsonArray = jsonObject.getJSONArray("results");
                posters = new ArrayList<>();
                Id = new ArrayList<>();
                Over = new ArrayList<>();
                ReliseDate = new ArrayList<>();
                Title = new ArrayList<>();
                Rate = new ArrayList<>();

                for (int i = 0; i < jsonArray.length(); i++) {
                    //  JSONObject movies=jsonArray.getJSONObject(i);
                    posters.add(jsonArray.getJSONObject(i).get("poster_path").toString());
                    Id.add(jsonArray.getJSONObject(i).get("id").toString());
                    Title.add(jsonArray.getJSONObject(i).get("original_title").toString());
                    Over.add(jsonArray.getJSONObject(i).get("overview").toString());
                    ReliseDate.add(jsonArray.getJSONObject(i).get("release_date").toString());
                    Rate.add(jsonArray.getJSONObject(i).get("vote_average").toString());


//                    MovieModel movie=new MovieModel(poster,name,id,backdrop,date,overall);
//                    list.addLast(movie);
                }


            } catch (Exception e) {
                Log.e("error", "Error ", e);
                return null;
            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
//            Log.d("Dataaaaaa",result);
            grid.setAdapter(new GridAdapter(getActivity(), posters));

            Log.d("IDssssss", "" + Id);
            Log.d("Postersssssssssssssssss", "" + posters);
            Log.d("Titlesssssssss", "" + Title);
            Log.d("Overrssssss", "" + Over);
            Log.d("Releseeeeeee", "" + ReliseDate);
        }


    }


    public class FavouriteMovies extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String... Url) {
            HttpURLConnection urlConnection = null;


            try {
//                 URL movieURL;
//                movieURL = new URL("https://api.themoviedb.org/3/movie/popular?api_key=f422e13255a0c5243a1627cb14581228");
//                HttpURLConnection urlConnection = (HttpURLConnection) movieURL.openConnection();
                final String API_KEY_PARAM = "api_key";
                Uri.Builder builder = new Uri.Builder();
                builder.scheme("https")
                        .authority("api.themoviedb.org")
                        .appendPath("3")
                        .appendPath("movie")
                        .appendPath(Url[0])
                        .appendQueryParameter(API_KEY_PARAM, "09ef905fb0a8f078de853a6aa6ac8983").build();


                URL url = new URL(builder.toString());

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();

                if (inputStream == null) {
                    // Nothing to do.
                    return null;
                }
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {

                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    // Stream was empty.  No point in parsing.
                    return null;
                }


                JSONObject jsonObject = new JSONObject(buffer.toString());
                // JSONArray jsonArray = jsonObject.getJSONArray("results");
                // publishProgress(jsonArray.length()+"");
                posters = new ArrayList<>();
                Id = new ArrayList<>();
                Over = new ArrayList<>();
                ReliseDate = new ArrayList<>();
                Title = new ArrayList<>();
                Rate = new ArrayList<>();

                posters.add(jsonObject.get("poster_path").toString());
                Id.add(jsonObject.get("id").toString());
                Title.add(jsonObject.get("original_title").toString());
                Over.add(jsonObject.get("overview").toString());
                ReliseDate.add(jsonObject.get("release_date").toString());
                Rate.add(jsonObject.get("vote_average").toString());

//                for (int i = 0; i < jsonArray.length(); i++) {
//                    //  JSONObject movies=jsonArray.getJSONObject(i);
//                    posters.add(jsonArray.getJSONObject(i).get("poster_path").toString());
//                    Id.add(jsonArray.getJSONObject(i).get("id").toString());
//                    Title.add(jsonArray.getJSONObject(i).get("original_title").toString());
//                    Over.add(jsonArray.getJSONObject(i).get("overview").toString());
//                    ReliseDate.add(jsonArray.getJSONObject(i).get("release_date").toString());
//                    //   Rate.add((jsonArray.getJSONObject(i).get("vote_average").toString());
//
//
////                    MovieModel movie=new MovieModel(poster,name,id,backdrop,date,overall);
////                    list.addLast(movie);
//                }


            } catch (Exception e) {
                Log.e("error", "Error ", e);
                return null;
            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (con>=DataID.length)
            {
                Log.d("posterdsssssssssss",""+posters);
                grid.setAdapter(new GridAdapter(getActivity(), posters));

            }
            //  DB.getMovie(Integer.parseInt());


//           Log.d("Dataaaaaa",result);
//            grid.setAdapter(new GridAdapter(getActivity(),posters));
//            Log.d("IDssssss", "" + Id);
//            Log.d("Postersssssssssssssssss",""+posters);
//            Log.d("Titlesssssssss",""+Title);
//            Log.d("Overrssssss", "" + Over);
//            Log.d("Releseeeeeee", "" + ReliseDate);


        }
    }
}




