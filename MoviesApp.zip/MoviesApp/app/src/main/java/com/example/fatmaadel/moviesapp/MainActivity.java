      package com.example.fatmaadel.moviesapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

public class MainActivity extends AppCompatActivity   {

    private static final String DetailFragment = "DF";
    public static boolean istablet =false;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (findViewById(R.id.frame) != null) {
            if (savedInstanceState != null) {
                return;


            }
            istablet = true;
            DetailActivityFragment detialedFragment = new DetailActivityFragment();
            detialedFragment.setArguments(getIntent().getExtras());
            getSupportFragmentManager().beginTransaction().add(R.id.frame, detialedFragment);


        }

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }


    }

